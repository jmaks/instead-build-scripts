Unzip this archive into ~/.instead/games/
