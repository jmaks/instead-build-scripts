#ifndef _WINCE_EXTERNAL_H
#define _WINCE_EXTERNAL_H

#define PATH_MAX 255
#define errno 0
#define strerror(a) ""
#define putenv(a) ;
#define setlocale(a, b) ;

#endif
