#ifdef S60
#include "s60.h"
#endif

#include "util.h"
#include "cache.h"
#include "graphics.h"
#include "sound.h"
#include "game.h"
#include "themes.h"
#include "menu.h"
#include "config.h"
#include "input.h"
#include "instead.h"
